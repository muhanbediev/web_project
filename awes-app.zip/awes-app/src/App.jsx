import { BrowserRouter, Route, Switch, Link } from "react-router-dom";
import MovieList from "./comp/MovieList";
import Search from "./comp/Search";
import Form from "./comp/Form";
import Upcoming from "./comp/Upcoming";
import Movie from "./Movie";
import Pop from "./comp/Pop";
import "./style.css";


function App() {
  return (
    <div className="main">
      <div className="container">
        <BrowserRouter>
          <header>
            <Link to="/" className="logo">
              Movie App
            </Link>
            <div className="links">
              <Link to="/">Фильмы в кино</Link>
              <Link to="/upc">Скоро выйдут</Link>
              <Link to="/pop">Популярные фильмы</Link>
            </div>
            <div className="search">
              <Form />
            </div>
          </header>

          <Switch>
            <Route path="/upc">
              <Upcoming />
            </Route>
            <Route exact path="/">
              <MovieList />
            </Route>
            <Route path="/movie/:id">
              <Movie />
            </Route>
            <Route path="/search/:w">
              <Search />
            </Route>
            <Route path="/pop">
              <Pop />
            </Route>
          </Switch>
          <footer>
            Created by kemel
          </footer>
        </BrowserRouter>
      </div>
    </div>
  );
}

export default App;
